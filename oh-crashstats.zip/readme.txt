Crash Statistics was Generated on the Following Criteria::
----------------------------------------------------------

Generated On : 7/3/2024 2:02:10 PM
Order Number : OH240702213713389DC5BVG
From Date    : 6/1/2024
To Date      : 6/30/2024
County : Franklin County
Total Records : 1344
